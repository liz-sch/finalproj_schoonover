from flask import Flask
from flask import render_template
from flask import url_for, redirect, request
from flask_bootstrap import Bootstrap

import sqlite3

app	= Flask(__name__)
Bootstrap(app)

@app.route('/')
def home():
    return render_template('index.htm')

@app.route('/products.htm')
def products():
    return render_template('products.htm')
    
def create_databases():
    conn = sqlite3.connect('product_database.db')
    conn = sqlite3.connect('user_database.db')
    conn = sqlite3.connect('cart.db')
    conn.execute('CREATE TABLE product(productid INTEGER PRIMARY KEY, name TEXT, description TEXT, image TEXT, stock INTEGER, price REAL)')
    conn.execute('CREATE TABLE user(userid INTEGER PRIMARY KEY, name TEXT, password TEXT, email TEXT, address TEXT, zipcode INTEGER, city TEXT, state TEXT, country TEXT, phone TEXT)')
    conn.execute('CREATE TABLE cart(userid INTEGER, productid INTEGER, FOREIGN KEY(userid) REFERENCES user(userid), FOREIGN KEY(productid) REFERENCES product(productid))')

    conn.execute("INSERT INTO product ('productid', 'name', 'description', 'image', 'stock', 'price') VALUES ('001', 'Vintage Levi\'s Jeans', 'Waist size 32, 28 inch inseam. Vintage deadstock Levis denim from the 1990s.', '/flask_app/images/vtglevis01.jpg', '25', '$125');")
    
    print('Tables loaded successfully.')
    conn.close()

@app.route('/cart.htm')
def cart():
    return render_template('cart.htm')

@app.route('/signup.htm')
def signup():
    return render_template('signup.htm')

@app.route('/result.htm')
def result():
    return render_template('result.htm')

if __name__	==	'__main__':
    app.run(debug	=	True)